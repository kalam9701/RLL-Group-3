package com.collegemanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Eid;
	private String Ename;
	private String Email;
	private String Esubject;
	private String Edepartment;
	private String Econtact;
	
public Employee() {
		
	}
	
	public Employee(int eid, String ename, String email, String esubject, String edepartment, String econtact) {
	super();
	Eid = eid;
	Ename = ename;
	Email = email;
	Esubject = esubject;
	Edepartment = edepartment;
	Econtact = econtact;
}

	public int getEid() {
		return Eid;
	}

	public void setEid(int eid) {
		Eid = eid;
	}

	public String getEname() {
		return Ename;
	}

	public void setEname(String ename) {
		Ename = ename;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getEsubject() {
		return Esubject;
	}

	public void setEsubject(String esubject) {
		Esubject = esubject;
	}

	public String getEdepartment() {
		return Edepartment;
	}

	public void setEdepartment(String edepartment) {
		Edepartment = edepartment;
	}

	public String getEcontact() {
		return Econtact;
	}

	public void setEcontact(String econtact) {
		Econtact = econtact;
	}

	
	
}
