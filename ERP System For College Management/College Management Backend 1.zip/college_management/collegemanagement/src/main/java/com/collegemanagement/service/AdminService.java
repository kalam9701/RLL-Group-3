package com.collegemanagement.service;

import java.util.List;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.collegemanagement.entity.Admin;
import com.collegemanagement.entity.AdminRepo;
import com.collegemanagement.entity.Employee;
import com.collegemanagement.entity.EmployeeRepo;
import com.collegemanagement.entity.Student;
import com.collegemanagement.entity.StudentRepo;

@Service
public class AdminService {
	@Autowired
	AdminRepo arepo;
	
	@Autowired
	StudentRepo srepo;
	
	@Autowired
	EmployeeRepo erepo;
	
	public Admin addNewAdmin(Admin admin) {
		return arepo.save(admin);
	
	}
	public List<Admin> getAllAdmin() {
		return arepo.findAll();
	}
	
	public Admin updateAdmin(Admin admin)
	{
		Admin a1=arepo.searchAdmin(admin.getAname());
		a1.setApassword(admin.getApassword());
		arepo.save(a1);
		return a1;
	}
	
	public List<Student> getAllStudent()
	{
		return srepo.findAll();
	}

	public Student addNewStudent(Student student)
	{
		return srepo.save(student);
	}

	public List<Employee> getAllEmployee() {
		{
			return erepo.findAll();
		}
	}

	public Employee addNewEmployee(Employee employee) {
		{
			return erepo.save(employee);
		}
	}

	

	
}
