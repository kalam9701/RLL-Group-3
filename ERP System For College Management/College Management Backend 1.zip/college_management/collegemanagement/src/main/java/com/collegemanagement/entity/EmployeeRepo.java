package com.collegemanagement.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> { 

	@Query(value=("select * from employee where employee.ename= ? "), nativeQuery = true)
	public Employee searchEmployee(String ename);


}
