package com.collegemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collegemanagement.entity.Book;
import com.collegemanagement.entity.BookRepo;
import com.collegemanagement.entity.BookRequest;
import com.collegemanagement.entity.BookRequestRepo;
import com.collegemanagement.entity.Student;
import com.collegemanagement.entity.StudentRepo;


@Service
public class BookService {
    @Autowired
    BookRepo brepo;
    
    @Autowired
    StudentRepo srepo;
    
    @Autowired
    BookRequestRepo bookRequestRepo;
	public Book addNewBook(Book book) 
		{
			return brepo.save(book);
		}
	
	
	public List<Book> getAllBooks()
	{
		return brepo.findAll();
	}


	public Book getBookById(int bookId) {
		Book book = brepo.findById(bookId).get();
		return book;
	}


	public void requestBook(int bookId, int studentId) {
		BookRequest br=new BookRequest();
		Book book = brepo.findById(bookId).get();
		Student s = srepo.findById(studentId).get();
		br.setBook(book);
		br.setStudent(s);
		bookRequestRepo.save(br);
		
		
	}


	public List<BookRequest> getAllBookRequests() {
		return bookRequestRepo.findAll();
	}


	public List<BookRequest> getAllBookRequestByStudent(int studentId) {
		
		return bookRequestRepo.getallbookrequestbystudentid(studentId);
	}
	
	

}
