package com.collegemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.collegemanagement")
public class CollegemanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegemanagementApplication.class, args);
	}

}