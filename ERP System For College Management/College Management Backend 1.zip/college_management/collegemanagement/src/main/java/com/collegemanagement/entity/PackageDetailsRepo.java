package com.collegemanagement.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface PackageDetailsRepo extends JpaRepository<PackageDetails, Integer> {

	@Query(value=("select * from packagedetails where packagedetails.Pname= ? "), nativeQuery = true)
	public PackageDetails searchPackage(String pname); 

}
