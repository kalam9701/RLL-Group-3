package com.collegemanagement.entity;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table (name = "timetable")

public class Timetable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false)
	
	private int Id;
	private String Department;
	private String Date;
	private String Time;
	private String Subject;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "Pid")
	private PackageDetails Pdetails;
	public Timetable() {}
	
  
	public Timetable(int Id,String Department, String Date, String Time, String Subject, PackageDetails pdetails) {
		super();
		this.Id=Id;
		this.Department=Department;
		this.Date = Date;
		this.Time = Time;
		this.Subject = Subject;
		Pdetails = pdetails;
		}
	

	

	public int getId() {
		return Id;
	}


	public void setId(int id) {
		Id = id;
	}


	public String getDate() {
		return Date;
	}


	public void setDate(String date) {
		Date = date;
	}


	public String getTime() {
		return Time;
	}


	public void setTime(String time) {
		Time = time;
	}


	public String getSubject() {
		return Subject;
	}


	public void setSubject(String subject) {
		Subject = subject;
	}


	public PackageDetails getPdetails() {
		return Pdetails;
	}


	public void setPdetails(PackageDetails pdetails) {
		Pdetails = pdetails;
	}


	public String getDepartment() {
		return Department;
	}


	public void setDepartment(String department) {
		Department = department;
	}
	
	
	
}
