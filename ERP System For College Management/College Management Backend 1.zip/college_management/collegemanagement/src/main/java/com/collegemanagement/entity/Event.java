package com.collegemanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Event {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Evid;
	private String Evname;
	
	public Event()
	{
		
	}
	
	
	public Event(String evname) {
		super();
		Evname = evname;
	}
	public int getEvid() {
		return Evid;
	}
	public void setEvid(int evid) {
		Evid = evid;
	}
	public String getEvname() {
		return Evname;
	}
	public void setEvname(String evname) {
		Evname = evname;
	}

}
