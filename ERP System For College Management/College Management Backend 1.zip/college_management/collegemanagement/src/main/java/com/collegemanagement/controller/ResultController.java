package com.collegemanagement.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.collegemanagement.entity.Result;
import com.collegemanagement.service.ResultService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(path="/resultcollegemanagement")
public class ResultController {
	 @Autowired
	 
		private ResultService resultService;
		
		@GetMapping("/result/list")
		public List<Result> listresult()
		{
			return resultService.getAllResult();
		}
		
		@PostMapping("/result/insert")
		public Result Addresult(@RequestBody Result result)
		{
			return resultService.addNewResult(result);
		}

}