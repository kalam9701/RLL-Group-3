package com.college.system.CollegeManagementSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.college.system.CollegeManagementSystem.model.Assignment;
import com.college.system.CollegeManagementSystem.model.Result;
import com.college.system.CollegeManagementSystem.model.Timetables;
import com.college.system.CollegeManagementSystem.service.FacultyService;
import com.college.system.CollegeManagementSystem.service.LoginService;

@RestController
@RequestMapping("/faculty")
public class FacultyController {
	
	@Autowired
	FacultyService facultyService;
	
	@Autowired
	LoginService loginService;
		
	@GetMapping(value = "/login/{username}/{password}")
	public String login(@PathVariable String username,@PathVariable String password) { 
	
      	String loginStatus = loginService.authenticateFacultyLogin(username, password);
		return loginStatus;
	}
	
	@PostMapping(value = "/addTimeTable")
	public Timetables addTimeTable(@RequestBody Timetables timetables) {
		return facultyService.addTimeTable(timetables);
	}

	@PostMapping(value= "/addAssignment")
	public Assignment addAssignment(@RequestBody Assignment assignment) {
		return facultyService.addAssignment(assignment);
			}
	
	@PostMapping(value= "/addResult")
	public Result addResult(@RequestBody Result result) {
		return facultyService.addResult(result);
			}
	
	
}
