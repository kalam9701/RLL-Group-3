package com.college.system.CollegeManagementSystem.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.college.system.CollegeManagementSystem.model.Admin;
import com.college.system.CollegeManagementSystem.model.Faculty;


@Repository
public interface FacultyRepo extends JpaRepository<Faculty, Integer> {

	@Query(value ="select t.* from Faculty t where t.username=:username and t.password=:password",nativeQuery = true)
	Faculty findByUsernameAndPasswordAndUser(String username, String password);

	
	
}
