package com.college.system.CollegeManagementSystem.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.college.system.CollegeManagementSystem.model.Timetables;

@Repository
public interface TimeTableRepo extends JpaRepository<Timetables, Integer> {

	@Query(value = "select t.* from Timetables t where t.department =:department and t.batch =:batch",nativeQuery = true)
	List<Timetables> findByDepartmentAndBatch(@Param("department") String department,@Param("batch") String batch);

}
