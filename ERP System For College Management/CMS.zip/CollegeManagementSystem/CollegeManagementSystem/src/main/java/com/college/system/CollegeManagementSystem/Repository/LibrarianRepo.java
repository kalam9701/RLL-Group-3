package com.college.system.CollegeManagementSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.college.system.CollegeManagementSystem.model.Librarian;


@Repository
public interface LibrarianRepo extends JpaRepository<Librarian, Integer>{

	@Query(value ="select t.* from Librarian t where t.username=:username and t.password=:password",nativeQuery = true)
	Librarian findByUsernameAndPasswordAndUser(String username, String password);
	

}
