package com.college.system.CollegeManagementSystem.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.college.system.CollegeManagementSystem.model.Faculty;
import com.college.system.CollegeManagementSystem.model.Librarian;
import com.college.system.CollegeManagementSystem.model.Student;
import com.college.system.CollegeManagementSystem.service.AdminService;
import com.college.system.CollegeManagementSystem.service.LoginService;

@RestController
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	LoginService loginService;
	
	@Autowired
	AdminService adminService;

	@GetMapping(value = "/getfacultylist")
	public List<Faculty> fetchAddFacultyList() {
		List<Faculty> getfaculty = new ArrayList<Faculty>();
		getfaculty = adminService.fetchAddFacultyList();
		return getfaculty;
	}

	@PostMapping(value = "/addfaculty")
	public Faculty saveAddFaculty(@RequestBody Faculty faculty) {
		return adminService.saveAddFacultyToDB(faculty);
	}

	@GetMapping("/getfacultybyid/{fid}")
	public Faculty fetchAddFacultyById(@PathVariable int fid) {
		return adminService.fetchAddFacultyById(fid).get();
	}

	@DeleteMapping("/deletefacultybyid/{fid}")
	public String DeleteAddFacultyById(@PathVariable int fid) {
		return adminService.deleteAddFacultyById(fid);
	}
     @GetMapping(value = "/getlibrarianlist") public List<Librarian>
	  fetchLibrarianList() { List<Librarian> librarians = new
	  ArrayList<Librarian>(); librarians = adminService.fetchLibrarianList();
	  return librarians; 
	  } 
	 	  
	  @PostMapping(value = "/addlibrarian") public Librarian
	  saveLibrarian(@RequestBody Librarian librarian) { return
	  adminService.saveLibrarianToDB(librarian); }
	  
	  @GetMapping("/getlibrarianbyid/{lid}") public Librarian
	  fetchLibrarinById(@PathVariable int lid) { return
	  adminService.fetchLibrarianById(lid).get(); }
	  
	  @DeleteMapping("/deletelibrarianbyid/{lid}") public String
	  DeleteLibrarinById(@PathVariable int lid) { return
	  adminService.deleteLibrarianById(lid); }
	  
	  @GetMapping(value = "/getstudentlist") public List<Student>
	  fetchStudentList() { List<Student> students = new ArrayList<Student>();
	  students = adminService.fetchStudentList(); return students; }
	  
	  @PostMapping(value = "/addstudent") public Student saveStudent(@RequestBody
	  Student student) { return adminService.saveStudentToDB(student); }
	  
	  @GetMapping("/getstudentbyid/{stid}") public Student
	  fetchStudentById(@PathVariable int stid) { return
	  adminService.fetchStudentById(stid).get(); }
	  
	  @DeleteMapping("/deletestudentbyid/{stid}") public String admin(@PathVariable
	  int stid) { return adminService.deleteStudentById(stid); }
	  
	  @GetMapping(value = "/login/{username}/{password}")
		public String login(@PathVariable String username,@PathVariable String password) { 
		
	      	String loginStatus = loginService.authenticateLogin(username, password);
			return loginStatus;
		}
	  
	 }
