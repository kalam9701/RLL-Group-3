package com.college.system.CollegeManagementSystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.college.system.CollegeManagementSystem.Repository.AssignmentRepo;
import com.college.system.CollegeManagementSystem.Repository.ResultRepo;
import com.college.system.CollegeManagementSystem.Repository.TimeTableRepo;
import com.college.system.CollegeManagementSystem.model.Assignment;
import com.college.system.CollegeManagementSystem.model.Result;
import com.college.system.CollegeManagementSystem.model.Timetables;

@Service
public class FacultyService {
	
	@Autowired
	TimeTableRepo timetableRepo;
	
	@Autowired 
	AssignmentRepo assignmentRepo;

	@Autowired
	ResultRepo resultRepo;
	
	public Timetables addTimeTable(Timetables timetables) {
		timetableRepo.save(timetables);
		return timetables;
	}
	
	public Assignment addAssignment(Assignment assignment) {
		assignmentRepo.save(assignment);
		return assignment;
	}
	
	public Result addResult(Result result) {
		resultRepo.save(result);
		return result;	
}
}