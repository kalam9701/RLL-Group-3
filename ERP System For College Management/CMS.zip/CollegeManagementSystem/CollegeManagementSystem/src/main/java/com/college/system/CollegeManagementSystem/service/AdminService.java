package com.college.system.CollegeManagementSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.college.system.CollegeManagementSystem.Repository.*;
import com.college.system.CollegeManagementSystem.model.Faculty;
import com.college.system.CollegeManagementSystem.model.Librarian;
import com.college.system.CollegeManagementSystem.model.Student;

@Service
public class AdminService {
	@Autowired
	private FacultyRepo FacultyRepo;

	
	  @Autowired private LibrarianRepo librarianRepo;
	  
	  @Autowired private StudentRepo studentRepo;
	  
	  
	 	
	public List<Faculty> fetchAddFacultyList(){
		return FacultyRepo.findAll();
		
	}
	
	public Faculty saveAddFacultyToDB(Faculty faculty)
	{
		FacultyRepo.save(faculty);
		return faculty;
	}
	
	public Optional<Faculty> fetchAddFacultyById(int fid) {
		return FacultyRepo.findById(fid);	
	}
	
public String deleteAddFacultyById(int fid) {
		
		String result;
		try { 
			FacultyRepo.deleteById(fid);
		result = "Faculty successfully deleted";
		
		
	}catch (Exception e) {
		result = "Faculty with id is not deleted";
	
	}
		return result;
	}
	
	  public List<Librarian> fetchLibrarianList(){ return librarianRepo.findAll();
	  
	  } //add data 
	  public Librarian saveLibrarianToDB(Librarian librarian) {
	  librarianRepo.save(librarian); return librarian; }
	  
	  //find by id 
	  public Optional<Librarian> fetchLibrarianById(int lid) { return
	  librarianRepo.findById(lid); }
	  
	  public String deleteLibrarianById(int lid) {
	  
	  String result; try { librarianRepo.deleteById(lid); result =
	  "Librarian successfully deleted";
	  
	  
	  }catch (Exception e) { result = "Librarian with id is not deleted";
	  
	  } return result; }
	  
	  //view data 
	  public List<Student> fetchStudentList(){ return
	  studentRepo.findAll();
	  
	  } //add data 
	  public Student saveStudentToDB(Student student) {
	  studentRepo.save(student); return student; }
	  
	  //find by id 
	  public Optional<Student> fetchStudentById(int stid) { return
	  studentRepo.findById(stid); }
	  
	  public String deleteStudentById(int stid) {
	  
	  String result; try { studentRepo.deleteById(stid); result =
	  "Student successfully deleted";
	  
	  
	  }catch (Exception e) { result = "Student with id is not deleted";
	  
	  } return result; }
	  
	 }
