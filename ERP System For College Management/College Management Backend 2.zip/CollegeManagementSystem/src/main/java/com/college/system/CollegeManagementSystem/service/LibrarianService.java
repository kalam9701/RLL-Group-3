package com.college.system.CollegeManagementSystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.college.system.CollegeManagementSystem.Repository.BookRepo;
import com.college.system.CollegeManagementSystem.model.Book;
import com.college.system.CollegeManagementSystem.model.Timetables;

@Service
public class LibrarianService {


	@Autowired
	BookRepo bookRepo;
	
	public void addBook(Book book) {
		bookRepo.save(book);
		
	}
	
	
}

