package com.college.system.CollegeManagementSystem.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "timetables")
public class Timetables implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	

@Id
int id;
String batch;
String department;
String session1;
String session2;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getBatch() {
	return batch;
}
public void setBatch(String batch) {
	this.batch = batch;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public String getSession1() {
	return session1;
}
public void setSession1(String session1) {
	this.session1 = session1;
}
public String getSession2() {
	return session2;
}
public void setSession2(String session2) {
	this.session2 = session2;
}

}
