package com.college.system.CollegeManagementSystem.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.college.system.CollegeManagementSystem.Repository.AssignmentRepo;
import com.college.system.CollegeManagementSystem.Repository.BookRepo;
import com.college.system.CollegeManagementSystem.Repository.ResultRepo;
import com.college.system.CollegeManagementSystem.Repository.TimeTableRepo;
import com.college.system.CollegeManagementSystem.model.Assignment;
import com.college.system.CollegeManagementSystem.model.Book;
import com.college.system.CollegeManagementSystem.model.Result;
import com.college.system.CollegeManagementSystem.model.Timetables;

@Service
public class StudentService {

	@Autowired
	TimeTableRepo timeTableRepo;
	@Autowired
	AssignmentRepo assignmentRepo;
	@Autowired
	ResultRepo resultRepo;
		@Autowired
	BookRepo bookRepo;

	public List<Timetables> fetchTimeTableList(String department,String batch) {
		// TODO Auto-generated method stub
		
		List<Timetables> timeTableList = new ArrayList<Timetables>();
		timeTableList = timeTableRepo.findByDepartmentAndBatch(department,batch);
		return timeTableList;
	}
	
	

	public List<Assignment> fetchAssignmentList(String department,String batch) {
		// TODO Auto-generated method stub
		
		List<Assignment> assignmentList = new ArrayList<Assignment>();
		assignmentList = assignmentRepo.findByDepartmentAndBatch(department, batch);
		return assignmentList;
		
	}	
	
	public List<Result> fetchResultList(String department,String batch) {
		// TODO Auto-generated method stub
		
		List<Result> resultList = new ArrayList<Result>();
		resultList = resultRepo.findByDepartmentAndBatch(department, batch);
		return resultList;
	}



	public List<Book> fetchBookList(String bookname, String author) {
		// TODO Auto-generated method stub
		List<Book> bookList = new ArrayList<Book>();
		bookList = bookRepo.findByBookNameAndAuthor(bookname, author);
		return bookList;
	}
	
}
