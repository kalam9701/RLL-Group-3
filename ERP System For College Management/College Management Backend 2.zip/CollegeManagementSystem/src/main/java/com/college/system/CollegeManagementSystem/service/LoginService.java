package com.college.system.CollegeManagementSystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.college.system.CollegeManagementSystem.Repository.AdminRepo;
import com.college.system.CollegeManagementSystem.Repository.FacultyRepo;
import com.college.system.CollegeManagementSystem.Repository.LibrarianRepo;
import com.college.system.CollegeManagementSystem.Repository.StudentRepo;
import com.college.system.CollegeManagementSystem.model.Admin;
import com.college.system.CollegeManagementSystem.model.Faculty;
import com.college.system.CollegeManagementSystem.model.Librarian;
import com.college.system.CollegeManagementSystem.model.Student;
@Service
public class LoginService {
@Autowired
AdminRepo adminRepo;

@Autowired
FacultyRepo facultyRepo;

@Autowired
LibrarianRepo librarianRepo;

@Autowired
StudentRepo studentRepo;
	

	public Admin authenticateLogin(String username, String password) {
		// TODO Auto-generated method stub
		Admin adminLogin = adminRepo.findByUsernameAndPasswordAndUser(username,password);
		if(adminLogin!=null) {
			return adminLogin;
		}
		return null;
	}
	
	public Faculty authenticateFacultyLogin(String username, String password) {
		// TODO Auto-generated method stub
		Faculty facultyLogin = facultyRepo.findByUsernameAndPasswordAndUser(username,password);
		if(facultyLogin!=null) {
			return facultyLogin;
		}
		return null;
	}
	
	public String authenticateLibrarianLogin(String username, String password) {
		// TODO Auto-generated method stub
		Librarian librarianLogin = librarianRepo.findByUsernameAndPasswordAndUser(username,password);
		if(librarianLogin!=null) {
			return "success";
		}
		return "failed";
	}

	public Student authenticateStudentLogin(String username, String password) {
		// TODO Auto-generated method stub
		Student studentLogin = studentRepo.findByUsernameAndPasswordAndUser(username,password);
		if(studentLogin!=null) {
			return studentLogin;
		}
		return null;
	}
}
