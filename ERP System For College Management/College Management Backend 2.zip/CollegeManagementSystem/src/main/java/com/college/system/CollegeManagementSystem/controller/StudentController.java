package com.college.system.CollegeManagementSystem.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.college.system.CollegeManagementSystem.model.Assignment;
import com.college.system.CollegeManagementSystem.model.Book;
import com.college.system.CollegeManagementSystem.model.Faculty;
import com.college.system.CollegeManagementSystem.model.Librarian;
import com.college.system.CollegeManagementSystem.model.Result;
import com.college.system.CollegeManagementSystem.model.Student;
import com.college.system.CollegeManagementSystem.model.Timetables;
import com.college.system.CollegeManagementSystem.service.LoginService;
import com.college.system.CollegeManagementSystem.service.StudentService;

@RestController
@RequestMapping("/student")
@CrossOrigin("*")
public class StudentController {

	@Autowired
	StudentService studentService;
	
	@Autowired
	LoginService loginService;
		
	@PostMapping(value = "/login")
	public Student login(@RequestBody Student student) { 
		System.out.println(student.toString());
      	return loginService.authenticateStudentLogin(student.getUsername(), student.getPassword());
		
	}
	
	 @GetMapping(value = "/getTimeTable/{department}/{batch}") 
	 public List<Timetables> fetchTimeTable(@PathVariable String department,@PathVariable String batch) 
	{ 
		 List<Timetables> timeTableList = new ArrayList<Timetables>(); 
		 timeTableList = studentService.fetchTimeTableList(department,batch);
	  return timeTableList; 
	  } 
	 
	 @GetMapping(value = "/getAssignment/{department}/{batch}")
	 public List<Assignment> fetchAssigment(@PathVariable String department,@PathVariable String batch) 
		{ 
			 List<Assignment> assignmentList = new ArrayList<Assignment>(); 
			 assignmentList = studentService.fetchAssignmentList(department,batch);
		  return assignmentList; 
		  }
	 
	 @GetMapping(value = "/getResult/{department}/{batch}")
	 public List<Result> fetchResult(@PathVariable String department,@PathVariable String batch) 
		{ 
			 List<Result> resultList = new ArrayList<Result>(); 
			 resultList = studentService.fetchResultList(department,batch);
		  return resultList; 
		}    

	 
	 @GetMapping(value = "/getBook/{bookname}/{author}")
	 public List<Book> fetchBook(@PathVariable String bookname,@PathVariable String author) 
		{ 
			 List<Book> bookList = new ArrayList<Book>(); 
			 bookList = studentService.fetchBookList(bookname,author);
		  return bookList; 
		}    


}

