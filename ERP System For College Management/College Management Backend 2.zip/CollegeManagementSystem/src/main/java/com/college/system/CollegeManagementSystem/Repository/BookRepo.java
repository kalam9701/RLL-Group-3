package com.college.system.CollegeManagementSystem.Repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.college.system.CollegeManagementSystem.model.Book;


@Repository
public interface BookRepo extends JpaRepository<Book, Integer> {

	@Query(value = "select t.* from book t where t.bookname =:bookname and t.author =:author",nativeQuery = true)
	List<Book> findByBookNameAndAuthor(@Param("bookname") String bookname,@Param("author") String author);

}
