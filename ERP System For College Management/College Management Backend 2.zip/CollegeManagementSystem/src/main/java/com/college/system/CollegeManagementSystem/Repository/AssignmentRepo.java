package com.college.system.CollegeManagementSystem.Repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.college.system.CollegeManagementSystem.model.Assignment;


@Repository
public interface AssignmentRepo extends JpaRepository<Assignment, Integer> {

	@Query(value = "select t.* from Assignment t where t.department =:department and t.batch =:batch",nativeQuery = true)
	List<Assignment> findByDepartmentAndBatch(@Param("department") String department,@Param("batch") String batch);

}
