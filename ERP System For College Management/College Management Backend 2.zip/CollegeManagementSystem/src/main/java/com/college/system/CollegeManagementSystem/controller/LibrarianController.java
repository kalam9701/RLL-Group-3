package com.college.system.CollegeManagementSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.college.system.CollegeManagementSystem.model.Book;
import com.college.system.CollegeManagementSystem.service.LibrarianService;
import com.college.system.CollegeManagementSystem.service.LoginService;

@RestController
@RequestMapping("/librarian")
public class LibrarianController {

	@Autowired
	LibrarianService librarianService;
	
	@Autowired
	LoginService loginService;
		
	@GetMapping(value = "/login/{username}/{password}")
	public String login(@PathVariable String username,@PathVariable String password) { 
	
      	String loginStatus = loginService.authenticateLibrarianLogin(username, password);
		return loginStatus;
	}
	
	@PostMapping(value = "/addBook")
	public Book addBook(@RequestBody Book book) {
		librarianService.addBook(book);
		return book;
	}
	
}
