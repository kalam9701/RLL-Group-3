package com.collegemanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class Exam {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int exid;
	private String subject;
	private String date;
	private String time;
	private String totalmarks;
	
	public Exam(String subject, String date, String time, String totalmarks) {
		super();
		this.subject = subject;
		this.date = date;
		this.time = time;
		this.totalmarks = totalmarks;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public Exam()
	{
		
	}
	

	public int getExid() {
		return exid;
	}
	public void setExid(int exid) {
		this.exid = exid;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getTotalmarks() {
		return totalmarks;
	}
	public void setTotalmarks(String totalmarks) {
		this.totalmarks = totalmarks;
	}

}
