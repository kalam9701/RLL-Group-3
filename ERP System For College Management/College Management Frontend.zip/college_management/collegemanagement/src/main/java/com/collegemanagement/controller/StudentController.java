package com.collegemanagement.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.collegemanagement.entity.Student;
import com.collegemanagement.service.StudentService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping(path="/collegemanagement/student")
public class StudentController {

	@Autowired
	private StudentService studentService;
	
	@PostMapping("/add")
	public Student addStudent(@RequestBody Student student)
	{
		return studentService.addNewStudent(student);
	}
	
	@GetMapping("/list")
	public List<Student> listStudents()
	{
		return studentService.getAllStudent();
	}
	
	@GetMapping("/by-id")
	  public Student getStudentById(@RequestParam int studentId) {
		 return studentService.getStudentById(studentId);
	  }
	@PutMapping("/update-password")
	public Student updatePwd(@RequestBody Student student)
	{
		return studentService.updateStudentPwd(student);
	}
	
	@PutMapping("/edit")
	public Student updateStudent(@RequestBody Student student)
	{
		return studentService.updateStudentDetails(student);
	}
	
	
	@PutMapping("/delete")
	public void removeStudent(@RequestBody Student student)
	{
		studentService.removeStudentDetails(student);
	}
}