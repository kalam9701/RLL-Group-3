package com.collegemanagement.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepo extends JpaRepository<Student, Integer> {

	@Query(value=("select * from student where student.name= ? "), nativeQuery = true)
	public Student searchStudent(String name);
}