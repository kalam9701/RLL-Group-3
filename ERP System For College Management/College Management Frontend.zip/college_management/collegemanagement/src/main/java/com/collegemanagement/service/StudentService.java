package com.collegemanagement.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.collegemanagement.entity.Student;
import com.collegemanagement.entity.StudentRepo;

@Service
public class StudentService {

	@Autowired
	StudentRepo srepo;
	
	public Student addNewStudent(Student student)
	{
		return srepo.save(student);
	}
	
	public List<Student> getAllStudent()
	{
		return srepo.findAll();
	}
	public Student updateStudentPwd(Student student)
	{
		Student s1=srepo.searchStudent(student.getName());
		s1.setPassword(student.getPassword());
		srepo.save(s1);
		return s1;
	}
	
	public Student updateStudentDetails(Student student)
	{
		Student s2=srepo.getById(student.getId());
		s2.setName(student.getName());
		s2.setEmailid(student.getEmailid());
		s2.setDepartment(student.getDepartment());
		s2.setBatch(student.getBatch());
		srepo.save(s2);
		return s2;
	}
	
	public Student updateStudentPackageDetails(Student student)
	{
		Student s3=srepo.getById(student.getId());
		s3.setPdetails(student.getPdetails());
		srepo.save(s3);
		return s3;
	}
	
	public void removeStudentDetails(Student student)
	{
		srepo.deleteById(student.getId());
	}

	public Student getStudentById(int studentId) {
		Student student = srepo.findById(studentId).get();
		return student;
	}
}