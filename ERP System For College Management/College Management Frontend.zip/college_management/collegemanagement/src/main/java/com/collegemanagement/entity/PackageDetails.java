package com.collegemanagement.entity;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class PackageDetails implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false)
	private int Pid;
	private String Pname;
	private String Pstudentattendance;
	private String Pstudenttimetable;
	private String Pfacultyname;
	private String Pfacultypassword;
	private String Plibrarianname;
	private String Plibrarianpassword;
	private String Pbookname;
	private String Pbookauthor;
	private int Pbookprice;
	
	@OneToMany(mappedBy = "Pdetails")
	private List<Student> student = new ArrayList<>();
	
	public PackageDetails() {
		
	}

	

	public PackageDetails(int pid, String pname, String pstudentattendance, String pstudenttimetable,
			String pfacultyname, String pfacultypassword, String plibrarianname, String plibrarianpassword,
			String pbookname, String pbookauthor, int pbookprice, List<Student> student) {
		super();
		Pid = pid;
		Pname = pname;
		Pstudentattendance = pstudentattendance;
		Pstudenttimetable = pstudenttimetable;
		Pfacultyname = pfacultyname;
		Pfacultypassword = pfacultypassword;
		Plibrarianname = plibrarianname;
		Plibrarianpassword = plibrarianpassword;
		Pbookname = pbookname;
		Pbookauthor = pbookauthor;
		Pbookprice = pbookprice;
		this.student = student;
	}



	public int getPid() {
		return Pid;
	}



	public void setPid(int pid) {
		Pid = pid;
	}



	public String getPname() {
		return Pname;
	}



	public void setPname(String pname) {
		Pname = pname;
	}



	public String getPstudentattendance() {
		return Pstudentattendance;
	}



	public void setPstudentattendance(String pstudentattendance) {
		Pstudentattendance = pstudentattendance;
	}



	public String getPstudenttimetable() {
		return Pstudenttimetable;
	}



	public void setPstudenttimetable(String pstudenttimetable) {
		Pstudenttimetable = pstudenttimetable;
	}



	public String getPfacultyname() {
		return Pfacultyname;
	}



	public void setPfacultyname(String pfacultyname) {
		Pfacultyname = pfacultyname;
	}



	public String getPfacultypassword() {
		return Pfacultypassword;
	}



	public void setPfacultypassword(String pfacultypassword) {
		Pfacultypassword = pfacultypassword;
	}



	public String getPlibrarianname() {
		return Plibrarianname;
	}



	public void setPlibrarianname(String plibrarianname) {
		Plibrarianname = plibrarianname;
	}



	public String getPlibrarianpassword() {
		return Plibrarianpassword;
	}



	public void setPlibrarianpassword(String plibrarianpassword) {
		Plibrarianpassword = plibrarianpassword;
	}



	public String getPbookname() {
		return Pbookname;
	}



	public void setPbookname(String pbookname) {
		Pbookname = pbookname;
	}



	public String getPbookauthor() {
		return Pbookauthor;
	}



	public void setPbookauthor(String pbookauthor) {
		Pbookauthor = pbookauthor;
	}



	public int getPbookprice() {
		return Pbookprice;
	}



	public void setPbookprice(int pbookprice) {
		Pbookprice = pbookprice;
	}



	public List<Student> getStudent() {
		return student;
	}



	public void setStudent(List<Student> student) {
		this.student = student;
	}



	
	

	
}
