
package com.collegemanagement.entity;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface AdminRepo  extends JpaRepository<Admin, Integer> {

	@Query(value=("select * from admin where admin.Aname= ? "), nativeQuery = true)
	public Admin searchAdmin(String aname);
}
